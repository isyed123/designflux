import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  Laptop, 
  Globe2, 
  Smartphone, 
  Bot, 
  Sparkles, 
  ChevronRight,
  Menu,
  X,
  Star,
  Users,
  Mail,
  Hexagon
} from 'lucide-react';
import { ContactForm } from './components/ContactForm';
import { AILeadForm } from './components/AILeadForm';
import { Portfolio } from './components/Portfolio';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [showAILeadForm, setShowAILeadForm] = useState(false);
  const [activeTab, setActiveTab] = useState('websites');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'nav-scrolled' : 'bg-transparent'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center">
              <div className="flex items-center gap-2">
                <Hexagon className="w-8 h-8 text-[#00bfa6]" />
                <span className="text-2xl font-bold">
                  Design<span className="text-[#00bfa6]">Flux</span>
                </span>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {['Home', 'Services', 'Portfolio', 'Pricing', 'About', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-white hover:text-[#00bfa6] transition-colors"
                >
                  {item}
                </button>
              ))}
              <button
                onClick={() => setShowAILeadForm(true)}
                className="bg-[#00bfa6] text-white px-6 py-2 rounded-full hover:bg-[#00a693] transition-colors"
              >
                Start a Project
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-white">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-[#1a1a1a] border-t border-gray-800">
            {['Home', 'Services', 'Portfolio', 'Pricing', 'About', 'Contact'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="block w-full text-left px-4 py-4 text-white hover:bg-gray-800"
              >
                {item}
              </button>
            ))}
            <button
              onClick={() => {
                setShowAILeadForm(true);
                setIsMenuOpen(false);
              }}
              className="block w-full text-left px-4 py-4 text-[#00bfa6] hover:bg-gray-800"
            >
              Start a Project
            </button>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="hero-gradient min-h-screen flex items-center justify-center pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-6xl md:text-7xl font-bold mb-6">
            Design Excellence,
            <br />
            <span className="text-[#00bfa6]">Delivered Monthly</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-10">
            Unlimited design services for modern businesses. One subscription, endless possibilities.
          </p>
          <button 
            onClick={() => setShowContactForm(true)}
            className="bg-[#00bfa6] text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-[#00a693] transition-colors flex items-center gap-2 mx-auto"
          >
            Start Your Design Journey <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Our Services</h2>
            <p className="text-gray-400 text-xl max-w-2xl mx-auto">
              Comprehensive design solutions for every aspect of your digital presence
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Laptop, title: 'Website Design', description: 'Beautiful, responsive websites that convert visitors into customers' },
              { icon: Globe2, title: 'Full Website Online', description: 'End-to-end web development with seamless deployment' },
              { icon: Sparkles, title: 'SaaS Applications', description: 'Custom SaaS solutions that scale with your business' },
              { icon: Smartphone, title: 'Mobile Applications', description: 'Native and cross-platform mobile apps for iOS and Android' },
              { icon: Bot, title: 'Custom AI Agents', description: 'Intelligent AI solutions tailored to your specific needs' }
            ].map((service, index) => (
              <div key={index} className="bg-gray-900 p-8 rounded-2xl hover:bg-gray-800 transition-colors cursor-pointer group">
                <service.icon className="w-12 h-12 text-[#00bfa6] mb-6" />
                <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
                <p className="text-gray-400 mb-6">{service.description}</p>
                <div className="flex items-center text-[#00bfa6] group-hover:text-[#00a693]">
                  Learn more <ChevronRight className="w-5 h-5 ml-2" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <Portfolio />

      {/* Pricing Section */}
      <section id="pricing" className="bg-gray-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Simple, Transparent Pricing</h2>
            <p className="text-gray-400 text-xl max-w-2xl mx-auto">
              No hidden fees. Cancel anytime. Scale your design needs as you grow.
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {[
              {
                name: "Basic",
                price: "$4,995",
                period: "/month",
                features: [
                  "One request at a time",
                  "Average 48 hour delivery",
                  "Unlimited brands",
                  "Unlimited users",
                  "Unlimited requests",
                  "Unlimited revisions"
                ]
              },
              {
                name: "Pro",
                price: "$7,995",
                period: "/month",
                features: [
                  "Two requests at a time",
                  "Average 48 hour delivery",
                  "Unlimited brands",
                  "Unlimited users",
                  "Unlimited requests",
                  "Unlimited revisions",
                  "Priority support"
                ],
                popular: true
              }
            ].map((plan, index) => (
              <div key={index} className={`bg-gray-800 rounded-2xl p-8 relative ${plan.popular ? 'border-2 border-[#00bfa6]' : ''}`}>
                {plan.popular && (
                  <div className="absolute top-0 right-8 bg-[#00bfa6] text-white px-4 py-1 rounded-b-lg">
                    Most Popular
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-400">{plan.period}</span>
                </div>
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center gap-2">
                      <ChevronRight className="w-5 h-5 text-[#00bfa6]" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => setShowContactForm(true)}
                  className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                    plan.popular
                      ? 'bg-[#00bfa6] text-white hover:bg-[#00a693]'
                      : 'bg-gray-700 text-white hover:bg-gray-600'
                  }`}
                >
                  Get Started
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Our Expertise</h2>
            <p className="text-gray-400 text-xl max-w-2xl mx-auto">
              Discover our comprehensive range of services and technical expertise
            </p>
          </div>
          
          <div className="mb-8 flex flex-wrap justify-center gap-4">
            {['websites', 'mobile', 'saas', 'ai'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                  activeTab === tab
                    ? 'bg-[#00bfa6] text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {tab === 'saas' ? 'SaaS Solutions' : 
                 tab === 'ai' ? 'AI Integration' :
                 tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          <div className="bg-gray-900 rounded-2xl p-8">
            <h3 className="text-2xl font-bold mb-4">
              {activeTab === 'websites' ? 'Website Design & Development' :
               activeTab === 'mobile' ? 'Mobile App Development' :
               activeTab === 'saas' ? 'SaaS Solutions' :
               'AI Integration'}
            </h3>
            <p className="text-gray-400 mb-8">
              {activeTab === 'websites' ? 'We create stunning, responsive websites that drive conversions and enhance user experience.' :
               activeTab === 'mobile' ? 'Native and cross-platform mobile applications that deliver exceptional user experiences.' :
               activeTab === 'saas' ? 'Custom SaaS platforms that scale with your business and meet your unique requirements.' :
               'Cutting-edge AI solutions to automate and enhance your business processes.'}
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              {(activeTab === 'websites' ? [
                'Custom WordPress Development',
                'E-commerce Solutions',
                'Landing Page Design',
                'Responsive Web Design',
                'Website Optimization',
                'SEO Integration'
              ] : activeTab === 'mobile' ? [
                'iOS App Development',
                'Android App Development',
                'React Native Solutions',
                'App UI/UX Design',
                'Mobile App Testing',
                'App Store Optimization'
              ] : activeTab === 'saas' ? [
                'Custom SaaS Development',
                'Cloud Integration',
                'API Development',
                'Database Design',
                'Security Implementation',
                'Scalability Planning'
              ] : [
                'Custom AI Models',
                'Natural Language Processing',
                'Machine Learning Integration',
                'AI Chatbots',
                'Predictive Analytics',
                'Data Processing'
              ]).map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <ChevronRight className="w-5 h-5 text-[#00bfa6]" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="bg-gray-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Get in Touch</h2>
            <p className="text-gray-400 text-xl max-w-2xl mx-auto">
              Ready to start your next project? We'd love to hear from you.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <Mail className="w-8 h-8 text-[#00bfa6] mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Email</h3>
              <p className="text-gray-400">hello@designflux.com</p>
            </div>
            <div className="text-center">
              <Users className="w-8 h-8 text-[#00bfa6] mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Office</h3>
              <p className="text-gray-400">123 Design Street<br />San Francisco, CA 94103</p>
            </div>
            <div className="text-center">
              <Star className="w-8 h-8 text-[#00bfa6] mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">Social</h3>
              <p className="text-gray-400">@designflux</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Hexagon className="w-8 h-8 text-[#00bfa6]" />
                <span className="text-2xl font-bold">
                  Design<span className="text-[#00bfa6]">Flux</span>
                </span>
              </div>
              <p className="text-gray-400">
                Transforming businesses through exceptional design solutions.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Website Design</li>
                <li>Mobile Apps</li>
                <li>SaaS Solutions</li>
                <li>AI Integration</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>About Us</li>
                <li>Portfolio</li>
                <li>Pricing</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Connect</h4>
              <div className="flex space-x-4">
                <Users className="w-6 h-6 text-[#00bfa6]" />
                <Star className="w-6 h-6 text-[#00bfa6]" />
                <Mail className="w-6 h-6 text-[#00bfa6]" />
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>© 2024 DesignFlux. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Contact Form Modal */}
      {showContactForm && (
        <ContactForm onClose={() => setShowContactForm(false)} />
      )}

      {/* AI Lead Form Modal */}
      {showAILeadForm && (
        <AILeadForm onClose={() => setShowAILeadForm(false)} />
      )}
    </div>
  );
}

export default App;
import React from 'react';
import { useForm } from 'react-hook-form';
import { supabase } from '../lib/supabase';
import { X } from 'lucide-react';

interface ProjectRequirementsFormProps {
  onClose: () => void;
  userId: string;
}

interface FormData {
  title: string;
  description: string;
  targetAudience: string;
  goals: string;
  timeline: string;
  budget: string;
  additionalNotes: string;
}

export function ProjectRequirementsForm({ onClose, userId }: ProjectRequirementsFormProps) {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitError, setSubmitError] = React.useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = React.useState(false);

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const { error } = await supabase
        .from('project_requirements')
        .insert([{
          user_id: userId,
          title: data.title,
          description: data.description,
          target_audience: data.targetAudience,
          goals: data.goals,
          timeline: data.timeline,
          budget: data.budget,
          additional_notes: data.additionalNotes
        }]);

      if (error) throw error;

      // Simulate calendar event creation (in a real app, use Google Calendar API)
      const meetingTime = new Date();
      meetingTime.setDate(meetingTime.getDate() + 2); // Schedule for 2 days from now
      
      console.log('Email sent to saint_40s@yahoo.com:', `
        New Project Requirements Submitted
        Title: ${data.title}
        Description: ${data.description}
        Meeting scheduled for: ${meetingTime.toLocaleString()}
      `);

      setSubmitSuccess(true);
    } catch (error: any) {
      setSubmitError(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 max-w-2xl w-full relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
        >
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold text-gray-900 mb-6">Project Requirements</h2>

        {submitSuccess ? (
          <div className="text-center py-8">
            <h3 className="text-xl font-semibold text-green-600 mb-2">Project Requirements Submitted!</h3>
            <p className="text-gray-600 mb-4">
              We'll review your requirements and schedule a meeting to discuss the details.
            </p>
            <button
              onClick={onClose}
              className="bg-[#ff6b00] text-white px-6 py-2 rounded-full hover:bg-[#ff5500] transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Project Title
              </label>
              <input
                {...register('title', { required: 'Project title is required' })}
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
              {errors.title && (
                <p className="text-red-500 text-sm mt-1">{errors.title.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Project Description
              </label>
              <textarea
                {...register('description', { required: 'Project description is required' })}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
              {errors.description && (
                <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="targetAudience" className="block text-sm font-medium text-gray-700 mb-1">
                Target Audience
              </label>
              <textarea
                {...register('targetAudience', { required: 'Target audience is required' })}
                rows={2}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
              {errors.targetAudience && (
                <p className="text-red-500 text-sm mt-1">{errors.targetAudience.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="goals" className="block text-sm font-medium text-gray-700 mb-1">
                Project Goals
              </label>
              <textarea
                {...register('goals', { required: 'Project goals are required' })}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
              {errors.goals && (
                <p className="text-red-500 text-sm mt-1">{errors.goals.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="timeline" className="block text-sm font-medium text-gray-700 mb-1">
                Timeline
              </label>
              <input
                {...register('timeline', { required: 'Timeline is required' })}
                type="text"
                placeholder="e.g., 2 months, Q2 2024"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
              {errors.timeline && (
                <p className="text-red-500 text-sm mt-1">{errors.timeline.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-1">
                Budget Range
              </label>
              <input
                {...register('budget', { required: 'Budget range is required' })}
                type="text"
                placeholder="e.g., $5,000 - $10,000"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
              {errors.budget && (
                <p className="text-red-500 text-sm mt-1">{errors.budget.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="additionalNotes" className="block text-sm font-medium text-gray-700 mb-1">
                Additional Notes
              </label>
              <textarea
                {...register('additionalNotes')}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#ff6b00] focus:border-[#ff6b00]"
              />
            </div>

            {submitError && (
              <p className="text-red-500 text-sm">{submitError}</p>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#ff6b00] text-white py-3 rounded-lg hover:bg-[#ff5500] transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Project Requirements'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
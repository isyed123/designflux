import React from 'react';
import { useForm } from 'react-hook-form';
import { supabase } from '../lib/supabase';
import { X } from 'lucide-react';

interface AILeadFormProps {
  onClose: () => void;
}

interface FormData {
  firstName: string;
  lastName: string;
  companyName: string;
  email: string;
  phone: string;
  linkedinUrl: string;
}

export function AILeadForm({ onClose }: AILeadFormProps) {
  const { register, handleSubmit, formState: { errors }, reset } = useForm<FormData>();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitError, setSubmitError] = React.useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = React.useState(false);

  const calculateScores = async (leadId: string, linkedinUrl: string) => {
    // Simulate AI scoring (in a real application, this would call an AI service)
    const scores = {
      company_size_score: Math.floor(Math.random() * 100),
      decision_maker_score: Math.floor(Math.random() * 100),
      budget_potential_score: Math.floor(Math.random() * 100),
      industry_fit_score: Math.floor(Math.random() * 100)
    };

    const totalScore = Object.values(scores).reduce((a, b) => a + b, 0) / 4;

    await supabase
      .from('lead_scores')
      .insert([{
        lead_id: leadId,
        ...scores,
        total_score: totalScore
      }]);

    // Simulate company research
    await supabase
      .from('company_research')
      .insert([{
        lead_id: leadId,
        company_size: '50-200 employees',
        industry: 'Technology',
        annual_revenue: '$5M-$10M',
        decision_makers: JSON.stringify([
          { name: 'John Doe', title: 'CTO' },
          { name: 'Jane Smith', title: 'CEO' }
        ]),
        company_background: 'Leading technology company in the B2B space'
      }]);

    // Send email notification
    const emailBody = `
      New lead received:
      Score: ${totalScore}/100
      LinkedIn: ${linkedinUrl}
    `;

    // In a real application, you would use a proper email service
    console.log('Email sent to saint_40s@yahoo.com:', emailBody);
  };

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const { data: lead, error } = await supabase
        .from('leads')
        .insert([{
          first_name: data.firstName,
          last_name: data.lastName,
          company_name: data.companyName,
          email: data.email,
          phone: data.phone,
          linkedin_url: data.linkedinUrl
        }])
        .select()
        .single();

      if (error) throw error;

      await calculateScores(lead.id, data.linkedinUrl);

      setSubmitSuccess(true);
      reset();
    } catch (error) {
      setSubmitError('An error occurred while submitting the form. Please try again.');
      console.error('Error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
        >
          <X size={24} />
        </button>

        <h2 className="text-2xl font-bold text-gray-900 mb-6">Start a Project</h2>

        {submitSuccess ? (
          <div className="text-center py-8">
            <h3 className="text-xl font-semibold text-green-600 mb-2">Thank you for your interest!</h3>
            <p className="text-gray-600 mb-4">Our AI agent is analyzing your information. We'll be in touch shortly.</p>
            <button
              onClick={onClose}
              className="bg-[#00bfa6] text-white px-6 py-2 rounded-full hover:bg-[#00a693] transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                First Name
              </label>
              <input
                {...register('firstName', { required: 'First name is required' })}
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#00bfa6] focus:border-[#00bfa6]"
              />
              {errors.firstName && (
                <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                Last Name
              </label>
              <input
                {...register('lastName', { required: 'Last name is required' })}
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#00bfa6] focus:border-[#00bfa6]"
              />
              {errors.lastName && (
                <p className="text-red-500 text-sm mt-1">{errors.lastName.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 mb-1">
                Company Name
              </label>
              <input
                {...register('companyName', { required: 'Company name is required' })}
                type="text"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#00bfa6] focus:border-[#00bfa6]"
              />
              {errors.companyName && (
                <p className="text-red-500 text-sm mt-1">{errors.companyName.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Company Email
              </label>
              <input
                {...register('email', {
                  required: 'Email is required',
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: 'Invalid email address'
                  }
                })}
                type="email"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#00bfa6] focus:border-[#00bfa6]"
              />
              {errors.email && (
                <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Phone Number
              </label>
              <input
                {...register('phone', { required: 'Phone number is required' })}
                type="tel"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#00bfa6] focus:border-[#00bfa6]"
              />
              {errors.phone && (
                <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="linkedinUrl" className="block text-sm font-medium text-gray-700 mb-1">
                LinkedIn Profile URL
              </label>
              <input
                {...register('linkedinUrl', { required: 'LinkedIn URL is required' })}
                type="url"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#00bfa6] focus:border-[#00bfa6]"
              />
              {errors.linkedinUrl && (
                <p className="text-red-500 text-sm mt-1">{errors.linkedinUrl.message}</p>
              )}
            </div>

            {submitError && (
              <p className="text-red-500 text-sm">{submitError}</p>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#00bfa6] text-white py-3 rounded-lg hover:bg-[#00a693] transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Processing...' : 'Submit'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
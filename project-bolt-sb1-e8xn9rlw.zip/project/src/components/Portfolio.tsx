import React from 'react';
import { ArrowRight } from 'lucide-react';

const portfolioItems = [
  {
    title: 'TechFlow SaaS Platform',
    category: 'SaaS Application',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80',
    description: 'Modern dashboard interface for data analytics'
  },
  {
    title: 'EcoTrack Mobile App',
    category: 'Mobile Application',
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&q=80',
    description: 'Sustainable living tracker for eco-conscious users'
  },
  {
    title: 'SmartHome Hub',
    category: 'Website Design',
    image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&q=80',
    description: 'IoT control center web application'
  },
  {
    title: 'AI-Powered Assistant',
    category: 'Custom AI Agent',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80',
    description: 'Intelligent customer service automation'
  },
  {
    title: 'HealthTech Platform',
    category: 'Full Website',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80',
    description: 'Complete healthcare management solution'
  },
  {
    title: 'FinanceAI Dashboard',
    category: 'SaaS Application',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80',
    description: 'AI-driven financial analytics platform'
  }
];

export function Portfolio() {
  const [activeFilter, setActiveFilter] = React.useState('all');

  const categories = ['all', ...new Set(portfolioItems.map(item => item.category))];
  
  const filteredItems = activeFilter === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeFilter);

  return (
    <div className="py-24" id="portfolio">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">Our Portfolio</h2>
          <p className="text-gray-400 text-xl max-w-2xl mx-auto">
            Explore our latest projects and see how we've helped businesses transform their digital presence
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveFilter(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-colors ${
                activeFilter === category
                  ? 'bg-[#00bfa6] text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, index) => (
            <div
              key={index}
              className="bg-gray-900 rounded-xl overflow-hidden group hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <span className="text-[#00bfa6] text-sm font-semibold">{item.category}</span>
                <h3 className="text-xl font-bold mt-2 mb-3">{item.title}</h3>
                <p className="text-gray-400 mb-4">{item.description}</p>
                <button className="flex items-center text-[#00bfa6] group-hover:text-[#00a693] transition-colors">
                  View Project <ArrowRight className="w-5 h-5 ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
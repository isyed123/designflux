/*
  # Add AI Lead Scoring System

  1. New Tables
    - `leads`
      - Stores lead information and AI agent interactions
      - Includes contact details and company information
    - `lead_scores`
      - Stores scoring information for leads
      - Includes various scoring metrics and total score
    - `company_research`
      - Stores detailed company research information
      - Includes decision makers and company background

  2. Security
    - Enable RLS on all new tables
    - Add policies for secure data access
*/

-- Create leads table
CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  company_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  linkedin_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create lead scores table
CREATE TABLE IF NOT EXISTS lead_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id),
  company_size_score int DEFAULT 0,
  decision_maker_score int DEFAULT 0,
  budget_potential_score int DEFAULT 0,
  industry_fit_score int DEFAULT 0,
  total_score int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create company research table
CREATE TABLE IF NOT EXISTS company_research (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid REFERENCES leads(id),
  company_size text,
  industry text,
  annual_revenue text,
  decision_makers jsonb,
  company_background text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE lead_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE company_research ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can insert leads"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can insert lead scores"
  ON lead_scores
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can insert company research"
  ON company_research
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Add indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_lead_scores_lead_id ON lead_scores(lead_id);
CREATE INDEX IF NOT EXISTS idx_company_research_lead_id ON company_research(lead_id);
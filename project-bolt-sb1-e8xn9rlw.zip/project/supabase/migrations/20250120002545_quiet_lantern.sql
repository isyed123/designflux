/*
  # Add Project Requirements and User Verification

  1. New Tables
    - `project_requirements`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `title` (text)
      - `description` (text)
      - `target_audience` (text)
      - `goals` (text)
      - `timeline` (text)
      - `budget` (text)
      - `additional_notes` (text)
      - `created_at` (timestamptz)
      - `status` (text)

  2. Security
    - Enable RLS on `project_requirements` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS project_requirements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  title text NOT NULL,
  description text NOT NULL,
  target_audience text,
  goals text,
  timeline text,
  budget text,
  additional_notes text,
  created_at timestamptz DEFAULT now(),
  status text DEFAULT 'pending'
);

ALTER TABLE project_requirements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can insert their own project requirements"
  ON project_requirements
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own project requirements"
  ON project_requirements
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);